<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Suitability Prediction</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .avatar-select {
            display: flex;
            align-items: flex-start;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1>Тест на принадлежность</h1>
        <form id="jobForm" action="/" method="POST">
            <div class="avatar-select">
                <!-- Добавляем класс "avatar-img" к изображениям и data-toggle и data-target атрибуты -->
                <input type="radio" id="avatar1" name="avatar" value="1">
                <label for="avatar1" class="avatar-img" data-toggle="modal" data-target="#successModal" data-info="">
                    <img src="static/img/8212540.png" alt="Avatar 1">
                </label>
                <input type="radio" id="avatar2" name="avatar" value="2">
                <label for="avatar2" class="avatar-img" data-toggle="modal" data-target="#successModal" data-info="">
                    <img src="static/img/8212540.png" alt="Avatar 2">
                </label>
            </div>
            <div class="form-group">
                <label for="resume">Специальность</label>
                <textarea class="form-control" placeholder="Разработчик мобильных приложений для iOS" id="resume" name="resume" rows="3" required></textarea>
            </div>
            <div class="form-group">
                <label for="experience">Опыт</label>
                <input type="text" class="form-control" placeholder="0" id="experience" name="experience" required>
            </div>
            <div class="form-group">
                <label for="education">Уровень Образования</label>
                <input type="text" class="form-control" placeholder="Высшее или Бакалавр или Студент или нет или..." id="education" name="education" required>
            </div>
            <div class="form-group">
                <label for="skills">Навыки</label>
                <input type="text" class="form-control" placeholder="SQL, MySQL, PostgreSQL, Python" id="skills" name="skills" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" placeholder="email" id="email" name="email" required>
            </div>
            <button type="submit" class="btn btn-primary">Отправить</button>
        </form>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="successModalLabel">Успех!</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Выводим данные в зависимости от выбранного аватара -->
                    <ul id="avatarData">
                        <li>Специальность: <span id="specialty"></span></li>
                        <li>Опыт: <span id="experienceData"></span></li>
                        <li>Уровень Образования: <span id="educationData"></span></li>
                        <li>Навыки: <span id="skillsData"></span></li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
            // Обработчик событий для изображений с классом "avatar-img"
            $('.avatar-img').click(function(){
                var avatarValue = $(this).prev().val(); // Получаем значение выбранного аватара
                var info = {
                    "1": {
                        specialty: "Опытный разработчик ПО с опытом работы в компании XYZ",
                        experience: "3-8",
                        education: "Высшее",
                        skills: "HTML, CSS, JavaScript"
                    },
                    "2": {
                        specialty: "Программист-аналитик с опытом работы в финансовой сфере",
                        experience: "1-5",
                        education: "Студент",
                        skills: "Python, R, Machine Learning"
                    }
                };
                var avatarInfo = info[avatarValue]; // Выбираем данные соответствующие выбранному аватару
                // Выводим данные в модальном окне
                $('#specialty').text(avatarInfo.specialty);
                $('#experienceData').text(avatarInfo.experience);
                $('#educationData').text(avatarInfo.education);
                $('#skillsData').text(avatarInfo.skills);
                $('#successModal').modal('show'); // Показываем модальное окно
            });

            // Обработчик событий для отправки формы
            $('#jobForm').submit(function(event) {
                // Проверяем, выбран ли аватар
                if (!$('input[name="avatar"]:checked').val()) {
                    // Если аватар не выбран, предотвращаем отправку формы и показываем предупреждение
                    event.preventDefault();
                    alert('Пожалуйста, выберите резюме.');
                }
            });
        });
    </script>
</body>
</html>

