import torch
from transformers import BertForSequenceClassification, BertTokenizer, AdamW, get_linear_schedule_with_warmup
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm
import pymorphy2
import pandas as pd
import os

def preprocess_data(tokenizer, text_data):
    input_ids = []
    attention_masks = []
    morph = pymorphy2.MorphAnalyzer()
    for text in text_data:
        encoded_dict = tokenizer(morph.parse(text.lower())[0].normal_form, truncation=True, padding='max_length', max_length=128, return_tensors='pt')
        input_ids.append(encoded_dict['input_ids'])
        attention_masks.append(encoded_dict['attention_mask'])
    
    input_ids = torch.cat(input_ids, dim=0)
    attention_masks = torch.cat(attention_masks, dim=0)
    return input_ids, attention_masks

def train_ber(tokenizer, model, text_data, labels, num_epochs=25, batch_size=64, model_save_path="modelP"):
    input_ids, attention_masks = preprocess_data(tokenizer, text_data)
    labels = torch.tensor(labels)
    
    dataset = TensorDataset(input_ids, attention_masks, labels)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    
    optimizer = AdamW(model.parameters(), lr=2e-5, eps=1e-8)
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=0, num_training_steps=len(dataloader) * num_epochs)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    
    for epoch in range(num_epochs):
        model.train()
        total_loss = 0
        for batch in tqdm(dataloader, desc=f'Epoch {epoch + 1}/{num_epochs}'):
            batch = tuple(t.to(device) for t in batch)
            input_ids, attention_mask, labels = batch
            optimizer.zero_grad()
            outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            total_loss += loss.item()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
        print(f"Average Loss: {total_loss / len(dataloader)}")

    if not os.path.exists(model_save_path):
        os.makedirs(model_save_path)
    
    model.save_pretrained(model_save_path)
    tokenizer.save_pretrained(model_save_path)

def load_model(model_dir):
    model = BertForSequenceClassification.from_pretrained(model_dir)
    tokenizer = BertTokenizer.from_pretrained(model_dir)
    return model, tokenizer

def predict(model, tokenizer, texts):
    model.eval()
    input_ids, attention_masks = preprocess_data(tokenizer, texts)
    
    dataset = TensorDataset(input_ids, attention_masks)
    dataloader = DataLoader(dataset, batch_size=32, shuffle=False)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    
    predictions = []
    with torch.no_grad():
        for batch in dataloader:
            batch = tuple(t.to(device) for t in batch)
            input_ids, attention_mask = batch
            outputs = model(input_ids, attention_mask=attention_mask)
            logits = outputs.logits
            predictions.append(logits.argmax(dim=-1).cpu().numpy())
    
    return [item for sublist in predictions for item in sublist]

if __name__ == "__main__":
    model_name = 'DeepPavlov/rubert-base-cased-sentence'
    model = BertForSequenceClassification.from_pretrained(model_name, num_labels=2)
    tokenizer = BertTokenizer.from_pretrained(model_name)
    
    data = pd.read_csv('data.csv', sep=';')
    data['Опыт'] = data['Опыт'].astype(str)
    cl1 = "<есть> " + data['Резюме'] + " <есть> " + data['Опыт'] + " <надо> " + data['Нужный опыт'] + " <есть> " + data['Образование'] + " <надо> " + data['Нужное образование'] + " <есть> " + data['Навыки'] + " <надо> " + data['Нужные навыки']
    print(str(cl1))
    txt = data['Пригодность'].values
    train_ber(tokenizer, model, cl1, txt)
    model, tokenizer = load_model("modelP")
    new_data = ["Стажер-программист в компании ABC 5 Среднее Python, C++, HTML"]
    predictions = predict(model, tokenizer, new_data)
    print(f"Predictions: {predictions}")
