from flask import Flask, render_template, request, redirect, url_for
import torch
from torch.utils.data import TensorDataset, DataLoader
from transformers import BertForSequenceClassification, BertTokenizer
import pandas as pd
import pymorphy2
import os

app = Flask(__name__)

data = {
    "1": {
        "experience": "3-8",
        "education": "Высшее",
        "skills": "HTML, CSS, JavaScript"
    },
    "2": {
        "experience": "1-5",
        "education": "Студент",
        "skills": "Python, R, Machine Learning"
    }
}

def take_need_position(position_id, data=data):
    if position_id in data:
        position = data[position_id]
        return position['experience'], position['education'], position['skills']
    else:
        return None, None, None

def preprocess_data(tokenizer, text_data):
    input_ids = []
    attention_masks = []
    morph = pymorphy2.MorphAnalyzer()
    for text in text_data:
        encoded_dict = tokenizer(morph.parse(text.lower())[0].normal_form, truncation=True, padding='max_length', max_length=128, return_tensors='pt')
        input_ids.append(encoded_dict['input_ids'])
        attention_masks.append(encoded_dict['attention_mask'])
    
    input_ids = torch.cat(input_ids, dim=0)
    attention_masks = torch.cat(attention_masks, dim=0)
    return input_ids, attention_masks

def predict(model, tokenizer, texts):
    model.eval()
    input_ids, attention_masks = preprocess_data(tokenizer, texts)
    
    dataset = TensorDataset(input_ids, attention_masks)
    dataloader = DataLoader(dataset, batch_size=32, shuffle=False)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    
    predictions = []
    with torch.no_grad():
        for batch in dataloader:
            batch = tuple(t.to(device) for t in batch)
            input_ids, attention_mask = batch
            outputs = model(input_ids, attention_mask=attention_mask)
            logits = outputs.logits
            predictions.append(logits.argmax(dim=-1).cpu().numpy())
    
    return [item for sublist in predictions for item in sublist]

# Load the trained model and tokenizer
model_dir = 'modelP'  # Path to the directory containing the saved model and tokenizer
model = BertForSequenceClassification.from_pretrained(model_dir)
tokenizer = BertTokenizer.from_pretrained(model_dir)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Extract form data
        position = request.form['avatar']
        resume = request.form['resume']
        experience = request.form['experience']
        education = request.form['education']
        skills = request.form['skills']
        required_experience, required_education, required_skills = take_need_position(str(position))
        # Combine the form data into the required format
        text_data = ["<есть> " + resume + " <есть> " + experience + " <надо> " + required_experience + " <есть> " + education + " <надо> " + required_education + " <есть> " + skills + " <надо> " + required_skills]
        
        # Predict using the model
        predictions = predict(model, tokenizer, text_data)
        
        # Redirect to the results page
        return redirect(url_for('result', prediction=predictions[0]))
    return render_template('form.php')

@app.route('/result/<prediction>')
def result(prediction):
	print(int(prediction))
	if int(prediction) == 1:
		return render_template('result.php', prediction="Вы приняты")
	else:
		return render_template('result.php', prediction="Вы не приняты")

if __name__ == '__main__':
    app.run(debug=True)

